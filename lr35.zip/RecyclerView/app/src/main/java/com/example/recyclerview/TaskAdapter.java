package com.example.recyclerview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TaskAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<Task> taskList;
    private Context context;
    public TaskAdapter(Context context, List<Task> taskList) {
        this.context = context;
        this.taskList = taskList;
    }
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.task, parent, false);
        return new RecyclerView.ViewHolder(view) {
        };
    }
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Task task = taskList.get(position);
        TextView tvTitle = holder.itemView.findViewById(R.id.tvTitle);
        TextView tvDate = holder.itemView.findViewById(R.id.tvDate);
        Button btnStatus = holder.itemView.findViewById(R.id.btnStatus);
        tvTitle.setText(task.getTitle());
        tvDate.setText(task.getDateCreated());
        btnStatus.setText(task.isCompleted() ? "Выполнено" : "Не выполнено");
        int bgColor = task.isCompleted()?
                context.getResources().getColor(android.R.color.darker_gray):
                context.getResources().getColor(android.R.color.white);
        holder.itemView.setBackgroundColor(bgColor);
        holder.itemView.setOnClickListener(v->{
            Toast.makeText(context,task.getDateCreated(), Toast.LENGTH_SHORT).show();
        });
        btnStatus.setOnClickListener(view -> {
            task.toggleStatus();
            notifyDataSetChanged();
        });
    }
    @Override
    public int getItemCount() {
        return taskList.size();
    }
}
