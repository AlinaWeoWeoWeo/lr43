package com.example.recyclerview;

public class Task {
    private String title;
    private String description;
    private boolean isCompleted;
    private String dateCreated;

    public Task(String title, String description, boolean isCompleted, String dateCreated){
        this.title = title;
        this.description = description;
        this.isCompleted = isCompleted;
        this.dateCreated = dateCreated;
    }
    public String getTitle(){
        return title;
    }
    public String getDescription() {
        return description;
    }
    public boolean isCompleted() {
        return isCompleted;
    }
    public String getDateCreated() {
        return dateCreated;
    }
    public void toggleStatus(){
        this.isCompleted = !this.isCompleted;
    }
}
