package com.example.lr432;

import android.os.AsyncTask;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class OpenGoogleTask extends AsyncTask<String, Void, String> {
    private TextView textView;
    public OpenGoogleTask(TextView textView) {
        this.textView = textView;
    }
    @Override
    protected String doInBackground(String... urls) {
        StringBuilder results = new StringBuilder();
        HttpsURLConnection urlConnection = null;
        try{
            URL url = new URL(urls[0]);
            urlConnection = (HttpsURLConnection) url.openConnection();
            BufferedReader reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null){
                results.append(line);
            }
            reader.close();
        }
        catch (Exception e){ e.printStackTrace();}
        finally { if (urlConnection != null){ urlConnection.disconnect();}}
        return results.toString();
    }
    protected void onPostExecute(String results){
        textView.setText(results);
    }
}
