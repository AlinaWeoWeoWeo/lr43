package com.example.lr432;

import android.os.AsyncTask;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.net.URL;

public class TestTask extends AsyncTask<String, Integer, String> {
    ProgressBar progressBar;
    TextView textView;
    @Override
    protected void onPreExecute() {
        progressBar.setProgress(0);
        progressBar.setVisibility(ProgressBar.VISIBLE);
    }
    protected String doInBackground(String... strings) {
        try {
            URL url = new URL(strings[0]);
        } catch (Exception e){}
        return "test";
    }
    protected void onProgressUpdate(Integer...values) {
        progressBar.setProgress(values[0]);
    }
    protected void onPostExecute(String result) {
        textView.setText(result);
    }
}
