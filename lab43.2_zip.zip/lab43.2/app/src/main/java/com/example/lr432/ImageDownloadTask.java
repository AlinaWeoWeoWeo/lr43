package com.example.lr432;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.ImageView;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class ImageDownloadTask extends AsyncTask<String, Void, Bitmap> {
    ImageView imageView;
    public ImageDownloadTask(ImageView imageView){
        this.imageView = imageView;
    }
    @Override
    protected Bitmap doInBackground(String... addresses) {
        Bitmap bitmap = null;
        InputStream in = null;
        try {
            URL url = new URL(addresses[0]);
            HttpsURLConnection urlConnection = (HttpsURLConnection) url.openConnection();
            urlConnection.connect();
            bitmap = BitmapFactory.decodeStream(urlConnection.getInputStream());
        } catch (IOException e) { e.printStackTrace();}
        finally {
            if (in != null){
                try {
                    in.close();
                } catch (IOException e) {
                    Log.e("ERROR", "Exeption while closing inputStream" + e);
                }
            }
            return bitmap;
        }
    }
    protected void onPostExecute(Bitmap result){
        imageView.setImageBitmap(result);
    }
}
