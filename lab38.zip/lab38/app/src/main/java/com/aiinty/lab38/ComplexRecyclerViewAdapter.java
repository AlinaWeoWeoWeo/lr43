package com.aiinty.lab38;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ComplexRecyclerViewAdapter  extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<User> items;
    private Context context;
    private final int USER = 0, IMAGE = 1;

    public ComplexRecyclerViewAdapter(List<User> items, Context context) {
        this.items = items;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());

                View v1 = inflater.inflate(R.layout.item_user, parent, false);
                return new UserViewHolder(v1);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
                UserViewHolder v1 = (UserViewHolder) holder;
                configureUserViewHolder(v1, position);
    }

    private void configureUserViewHolder(UserViewHolder vh1, int pos) {
        User user = (User) items.get(pos);
        if (user != null) {
            vh1.getUserNameLabel().setText("Name: " + user.name);
            vh1.getUserHometownLabel().setText(user.hometown);
            vh1.getUserAvatar().setImageResource(user.avatarRes);
        }
    }

    public void updateData(ArrayList<User> newData) {
        items.addAll(newData);
        notifyDataSetChanged();
    }

    @Override
    public int getItemViewType(int position) {
        return items.get(position).avatarRes == 0 ? USER : IMAGE;
    }

    @Override
    public int getItemCount() {
        return this.items.size();
    }
}