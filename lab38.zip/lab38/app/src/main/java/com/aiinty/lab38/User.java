package com.aiinty.lab38;

public class User {
    public String name;
    public String hometown;
    public int avatarRes;

    public User(String name, String hometown, int avatarRes) {
        this.name = name;
        this.hometown = hometown;
        this.avatarRes = avatarRes;
    }

    public String getName() {
        return name;
    }

    public String getHometown() {
        return hometown;
    }

    public int getAvatarRes() {
        return avatarRes;
    }

}
