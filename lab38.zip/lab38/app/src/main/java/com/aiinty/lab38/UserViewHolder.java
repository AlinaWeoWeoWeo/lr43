package com.aiinty.lab38;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

public class UserViewHolder extends RecyclerView.ViewHolder {

    private TextView userNameLabel, userHometownLabel;


    private ImageView userAvatar;

    public UserViewHolder(View itemView) {
        super(itemView);
        userNameLabel = itemView.findViewById(R.id.userItemTextName);
        userHometownLabel = itemView.findViewById(R.id.userItemTextHometown);
        userAvatar = itemView.findViewById(R.id.imageView);
    }

    public TextView getUserNameLabel() {
        return userNameLabel;
    }

    public void setUserNameLabel(TextView userNameLabel) {
        this.userNameLabel = userNameLabel;
    }

    public TextView getUserHometownLabel() {
        return userHometownLabel;
    }
    public ImageView getUserAvatar() {
        return userAvatar;
    }

    public void setUserAvatar(ImageView userAvatar) {
        this.userAvatar = userAvatar;
    }

    public void setUserHometownLabel(TextView userHometownLabel) {
        this.userHometownLabel = userHometownLabel;
    }
}