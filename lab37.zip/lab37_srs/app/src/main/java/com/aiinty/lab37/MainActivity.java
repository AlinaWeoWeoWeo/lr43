package com.aiinty.lab37;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.google.android.material.divider.MaterialDividerItemDecoration;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ComplexRecyclerViewAdapter complexRecyclerViewAdapter =
                new ComplexRecyclerViewAdapter(getSampleArrayList(), this);
        RecyclerView recyclerView = findViewById(R.id.rv);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(complexRecyclerViewAdapter);

        MaterialDividerItemDecoration decoration = new MaterialDividerItemDecoration(this, DividerItemDecoration.VERTICAL);
        decoration.setDividerInsetStart(16);
        decoration.setDividerInsetEnd(16);
        decoration.setLastItemDecorated(false);

        recyclerView.addItemDecoration(decoration);
    }

    private List<User> getSampleArrayList() {
        ArrayList<User> items = new ArrayList<>();
        items.add(new User("Anna Ivanova", "Moscow"));
        items.add(new User("Sergey Petrov", "Saint Petersburg"));
        items.add(new User("IVAN MAZUR", R.drawable.ic_launcher_background));
        items.add(new User("Olga Smirnova", "Novosibirsk"));
        items.add(new User("IVAN MAZUR", R.drawable.ic_launcher_background));
        items.add(new User("Alexey Volkov", "Yekaterinburg"));
        return items;
    }
}