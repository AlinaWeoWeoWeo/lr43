package com.aiinty.lab37;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.Objects;

`public class ComplexRecyclerViewAdapter  extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<User> items;
    private Context context;
    private final int USER = 0, IMAGE = 1;

    public ComplexRecyclerViewAdapter(List<User> items, Context context) {
        this.items = items;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());

        switch (viewType) {
            case USER:
                View v1 = inflater.inflate(R.layout.item_user, parent, false);
                return new UserViewHolder(v1);
            case IMAGE:
                View v2 = inflater.inflate(R.layout.item_image, parent, false);
                return new ImageViewHolder(v2);
        }
        throw  new IllegalArgumentException("Invalid view type");
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        switch (holder.getItemViewType()) {
            case USER:
                UserViewHolder v1 = (UserViewHolder) holder;
                configureUserViewHolder(v1, position);
                break;
            case IMAGE:
                ImageViewHolder v2 = (ImageViewHolder) holder;
                configureImageViewHolder(v2, position);
                break;
        }
    }

    private void configureUserViewHolder(UserViewHolder vh1, int pos) {
        User user = (User) items.get(pos);
        if (user != null) {
            vh1.getUserNameLabel().setText("Name: " + user.name);
            vh1.getUserHometownLabel().setText("Name: " + user.hometown);
        }
    }

    private void configureImageViewHolder(ImageViewHolder vh2, int pos) {
        User i = items.get(pos);
        vh2.getImageView().setImageResource(i.avatarRes);
        vh2.getName().setText("Name: " + i.name);
    }

    @Override
    public int getItemViewType(int position) {
        return items.get(position).avatarRes == 0 ? USER : IMAGE;
    }

    @Override
    public int getItemCount() {
        return this.items.size();
    }
}
`