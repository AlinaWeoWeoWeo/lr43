package com.aiinty.lab36_srs;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.LinearSnapHelper;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.google.android.material.divider.MaterialDividerItemDecoration;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        RecyclerView rv = findViewById(R.id.rv);
        MaterialDividerItemDecoration decoration = new MaterialDividerItemDecoration(this, MaterialDividerItemDecoration.VERTICAL);
        decoration.setDividerThickness(2);
        decoration.setDividerInsetStart(16);
        decoration.setDividerInsetEnd(16);
        decoration.setDividerColor(0x0F000000);

        rv.addItemDecoration(decoration);

        ImageAdapter adapter = new ImageAdapter(new ArrayList<>(Arrays.asList(
                new Item(R.drawable.rybov),
                new Item(R.drawable.ic_launcher_background),
                new Item(R.drawable.plitkov),
                new Item(R.drawable.images),
                new Item(R.drawable.ic_launcher_background),
                new Item(R.drawable.ic_launcher_background),
                new Item(R.drawable.ic_launcher_background),
                new Item(R.drawable.ic_launcher_background),
                new Item(R.drawable.ic_launcher_background),
                new Item(R.drawable.ic_launcher_background),
                new Item(R.drawable.ic_launcher_background),
                new Item(R.drawable.ic_launcher_background)
        )));
        rv.setAdapter(adapter);
        rv.setLayoutManager(new LinearLayoutManager(this));
        new LinearSnapHelper().attachToRecyclerView(rv);
        

    }
}