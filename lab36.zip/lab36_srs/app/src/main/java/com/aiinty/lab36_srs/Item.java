package com.aiinty.lab36_srs;

public class Item {
    public void setImgId(int imgId) {
        this.imgId = imgId;
    }

    public int getImgId() {
        return imgId;
    }

    private int imgId;

    public Item(int imgId) {
        this.imgId = imgId;
    }
}
