package com.aiinty.lab39;

public class TODO {
    private String title;
    private String text;

    public TODO(String title, String text) {
        this.title = title;
        this.text = text;
    }


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public static String toString(TODO todo) {
        return todo.getTitle() + "," + todo.getText();
    }

    public static TODO fromString(String str) {
        String[] parts = str.split(",");
        return new TODO(parts[0], parts[1]);
    }
}
