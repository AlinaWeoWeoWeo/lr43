package com.aiinty.lab39;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class TodoAdapter extends RecyclerView.Adapter<TodoAdapter.ViewHolder> implements Filterable {

    public TodoAdapter(List<TODO> todoList, List<TODO> filteredtodoList, OnItemClickListener listener, Context context) {
        this.todoList = todoList;
        this.filteredtodoList = filteredtodoList;
        this.listener = listener;
        this.context = context;
    }

    private List<TODO> todoList;
    private List<TODO> filteredtodoList;
    private OnItemClickListener listener;
    private Context context;
    
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.item_card, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        TODO item = todoList.get(position);
        holder.textViewTitle.setText(item.getTitle());
        holder.textViewText.setText(item.getText());
        
        holder.itemView.setOnClickListener(v -> listener.onItemClick(position));
        
        holder.itemView.setOnLongClickListener(v -> {
            listener.onItemLongClick(position);
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return todoList.size();
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                String charSequenceString = constraint.toString();
                if (charSequenceString.isEmpty()) {
                    filteredtodoList = todoList;
                } else {
                    List<TODO> filteredList = new ArrayList<>();
                    for (TODO todos : todoList) {
                        if (todos.getTitle().toLowerCase().contains(charSequenceString.toLowerCase()))
                        {
                            filteredList.add(todos);
                        }
                    }
                    filteredtodoList = filteredList;
                }
                FilterResults results = new FilterResults();
                results.values = filteredtodoList;
                return results;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                filteredtodoList = (List<TODO>) results.values;
                notifyDataSetChanged();
            }
        };
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        public TextView textViewTitle;
        public TextView textViewText;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewTitle = itemView.findViewById(R.id.textViewTitle);
            textViewText = itemView.findViewById(R.id.textViewText);
        }
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
        void onItemLongClick(int position);
    }
}
