package com.example.listview;

import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class TestAdapter extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView listView = findViewById(R.id.tvColors);

        List<UserData> userData = new ArrayList<>();
        userData.add(new UserData("Иванов Иван", "231251", null, null));
        userData.add(new UserData("Анна Смирнова",null,"какая-то почта", UserData.UserStatus.ONLINE.name()));
        userData.add(new UserData("Михаил Петров",null,"какая-то почта",UserData.UserStatus.OFFLINE.name()));

        BaseAdapter baseAdapter = new BaseAdapter(this, userData);
        listView.setAdapter(baseAdapter);
    }
}
