package com.example.listview;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
public class SimpleColor {


    public enum ColorValue {
        RED, BLUE, GREEN;

        public static String equalsColor(ColorValue color1, ColorValue color2){
            if(color1 == color2){
                return "Одинаковые цвета";
            }
            else{
                return  "Разные цвета";
            }
        }
    }

    public String label;
    public ColorValue color;

    public SimpleColor(String label, ColorValue color) {
        this.label = label;
        this.color = color;
    }



}
