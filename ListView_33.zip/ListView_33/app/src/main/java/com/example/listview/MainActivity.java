package com.example.listview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ListView tvColors;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        int type = 0;
        if (type == SimpleColor.ColorValue.RED.ordinal()) {
            Log.e("ColorValues", "RED");
        } else if (type == SimpleColor.ColorValue.BLUE.ordinal()) {
            Log.e("ColorValues", "BLUE");
        } else if (type == SimpleColor.ColorValue.BLUE.ordinal()) {
            Log.e("ColorValues", "RED");
        }

        Log.e("ColorValues2", SimpleColor.ColorValue.equalsColor(SimpleColor.ColorValue.RED, SimpleColor.ColorValue.RED));
        Log.e("ColorValues2", SimpleColor.ColorValue.equalsColor(SimpleColor.ColorValue.RED, SimpleColor.ColorValue.GREEN));


        tvColors = (ListView) findViewById(R.id.tvColors);
        ArrayList<SimpleColor> aColor = new ArrayList<SimpleColor>();

        for (int i = 0; i < 10; i++) {
            aColor.add(new SimpleColor("Blue" + i, SimpleColor.ColorValue.BLUE));
            aColor.add(new SimpleColor("Green" + i, SimpleColor.ColorValue.GREEN));
            aColor.add(new SimpleColor("Red" + i, SimpleColor.ColorValue.RED));


        }

        ColorAdapter adapter = new ColorAdapter(this,aColor);
        tvColors.setAdapter((adapter));
    }
}