package com.example.listview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.util.ArrayList;

public class ColorAdapter extends ArrayAdapter<SimpleColor> {
    public ColorAdapter(Context context, ArrayList<SimpleColor> colors) {
        super(context, 0, colors);
    }
    @Override
    public int getViewTypeCount(){
        return SimpleColor.ColorValue.values().length;
    }
    @Override
    public int getItemViewType(int position){
        return getItem(position).color.ordinal();
    }

    private View getInflatedLayoutForType(int type){
        if(type == SimpleColor.ColorValue.BLUE.ordinal()){
            return LayoutInflater.from(getContext()).inflate(R.layout.item_blue_color, null);
        }
        else if(type == SimpleColor.ColorValue.RED.ordinal()){
            return LayoutInflater.from(getContext()).inflate(R.layout.item_red_color, null);
        }
        else if(type == SimpleColor.ColorValue.GREEN.ordinal()){
            return LayoutInflater.from(getContext()).inflate(R.layout.item_green_color, null);
        }
        return null;
    }

    public View getView(int position, View convertView, ViewGroup parent){
        SimpleColor color = getItem(position);

        if (convertView == null){
            int type = getItemViewType(position);
            convertView = getInflatedLayoutForType(type);
        }

        TextView tvLabel = (TextView) convertView.findViewById(R.id.tvLabel1);
        if(tvLabel!=null){
            tvLabel.setText(color.label);
        }
        return convertView;
    }
}
