package com.example.listview;

public class UserData {

    private String name;
    private String number;
    private String email;
    private String status;

    public enum UserStatus {
        ONLINE, OFFLINE
    }

    public UserData(String name, String number, String email, String status) {
        this.name = name;
        this.number = number;
        this.email = email;
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public String getNumber() {
        return number;
    }

    public String getEmail() {
        return email;
    }

    public String getStatus() {
        return status;
    }
}
