package com.example.listview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;

public class BaseAdapter extends android.widget.BaseAdapter {

    private Context context;
    private List<UserData> contactList;

    public BaseAdapter(Context context, List<UserData> contactList) {
        this.context = context;
        this.contactList = contactList;
    }

    @Override
    public int getCount() {
        return contactList.size();
    }

    @Override
    public Object getItem(int position) {
        return contactList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        UserData userData = contactList.get(position);
        return (userData.getEmail() == null || userData.getEmail().isEmpty()) ? 0 : 1;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        int viewType = getItemViewType(position);
        UserData userData = contactList.get(position);

        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(
                    viewType == 0 ? R.layout.item_contact_phone : R.layout.item_contact_email,
                    parent, false
            );
        }

        if (viewType == 0) {
            TextView tvName = convertView.findViewById(R.id.tvName);
            TextView tvPhoneNumber = convertView.findViewById(R.id.tvPhoneNumber);

            tvName.setText(userData.getName());
            tvPhoneNumber.setText(userData.getNumber());
        } else {
            TextView tvName = convertView.findViewById(R.id.tvName);
            TextView tvEmail = convertView.findViewById(R.id.tvEmail);
            Button btnStatus = convertView.findViewById(R.id.btnStatus);

            tvName.setText(userData.getName());
            tvEmail.setText(userData.getEmail());

            boolean isOnline = userData.getStatus().equals(UserData.UserStatus.ONLINE.toString());
            btnStatus.setText(isOnline ? "ONLINE" : "OFFLINE");
            btnStatus.setEnabled(isOnline);
        }
        return convertView;
    }
}
