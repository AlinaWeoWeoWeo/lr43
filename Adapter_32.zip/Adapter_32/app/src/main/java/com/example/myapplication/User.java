package com.example.myapplication;

import android.content.Context;
import android.widget.TextView;

import java.util.ArrayList;

public class User {
    public String name;
    public String hometown;

    public User(String name, String hometown) {
        this.name = name;
        this.hometown = hometown;
    }


}
