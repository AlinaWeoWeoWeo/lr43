package com.example.myapplication;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.util.ArrayList;

public class AdapterViewHolder extends ArrayAdapter<User> {

    private static class ViewHolder {
        Button btButton;
        TextView name;
        TextView home;
    }
    private ArrayList<User> users;

    public AdapterViewHolder(Context context, ArrayList<User> users) {
        super(context, R.layout.lay2, users);
        this.users = users;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        User user = getItem(position);

        ViewHolder viewHolder;
        if (convertView == null) {
            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.lay2, parent, false);
            viewHolder.name = (TextView) convertView.findViewById(R.id.tvName);
            viewHolder.home = (TextView) convertView.findViewById(R.id.tvHome);
            viewHolder.btButton = (Button) convertView.findViewById(R.id.btButton);

            convertView.setTag(viewHolder);
        }
        else{
            viewHolder = (ViewHolder) convertView.getTag();
        }

        viewHolder.btButton.setOnClickListener(view -> {
            users.remove(position);
            notifyDataSetChanged();
        });

        viewHolder.name.setText(user.name);
        viewHolder.name.setText(user.hometown);

        return convertView;
    }
}
