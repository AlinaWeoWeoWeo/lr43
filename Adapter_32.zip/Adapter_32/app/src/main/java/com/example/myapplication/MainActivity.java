package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ArrayList<User> arrayOfuser = new ArrayList<User>();

        AdapterViewHolder adapter = new AdapterViewHolder(this,arrayOfuser);

        ListView listView = (ListView) findViewById(R.id.lvItems);
        listView.setAdapter(adapter);

        User newUser = new User("Nathan", "San Diego");
        User newUser1 = new User("Oleg","ShowField");
        adapter.add(newUser);
        adapter.add(newUser1);

    }
}

